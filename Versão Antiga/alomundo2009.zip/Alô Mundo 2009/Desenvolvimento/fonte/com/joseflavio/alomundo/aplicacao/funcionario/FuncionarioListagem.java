
/*
 *  Copyright (C) 2009 Jos� Fl�vio de Souza Dias J�nior
 *  
 *  This file is part of Jos� Fl�vio Livre - <http://www.joseflavio.com/livre/>.
 *  
 *  Jos� Fl�vio Livre is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *  
 *  Jos� Fl�vio Livre is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Jos� Fl�vio Livre. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.alomundo.aplicacao.funcionario;

import java.io.File;
import java.util.List;

import com.joseflavio.alomundo.Funcionario;
import com.joseflavio.alomundo.aplicacao.AloMundo;
import com.joseflavio.tqc.Dado;
import com.joseflavio.tqc.TomaraQueCaiaException;
import com.joseflavio.tqc.Viagem;
import com.joseflavio.tqc.aplicacao.ComandoApagar;
import com.joseflavio.tqc.aplicacao.ComandoImplementado;
import com.joseflavio.tqc.aplicacao.ComandoQuestionamento;
import com.joseflavio.tqc.aplicacao.ComandoVisitar;
import com.joseflavio.tqc.aplicacao.Listagem;
import com.joseflavio.tqc.dado.Arquivo;
import com.joseflavio.tqc.dado.Comando;
import com.joseflavio.tqc.molde.ListaMolde.ListaColunaPadrao;
import com.joseflavio.util.Lista;
import com.joseflavio.validacao.ValidacaoException;

/**
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2009
 */
public class FuncionarioListagem extends Listagem<AloMundo, Funcionario> {

	private Comando cmdAdicionar = new Comando( "Adicionar" );
	private Comando cmdFechar = new Comando( "Fechar" );
	
	public FuncionarioListagem( AloMundo aplicacao ) throws TomaraQueCaiaException {
		
		super( aplicacao, "Funcion�rios", "Funcion�rios" );
		
		construir();
		
	}

	protected void colunas() throws TomaraQueCaiaException {
		
		maisColunaInteiro( Funcionario.class, "id" );
		maisColunaTexto( Funcionario.class, "nome" );
		maisColunaData( Funcionario.class, "nascimento" );
		maisColunaTexto( Funcionario.class, "cargo" );
		maisColunaInteiro( Funcionario.class, "faltas" );
		maisColuna( new ColunaContrato() );
		maisColuna( new ColunaAcoes() );
		
	}

	protected void objetos( List<Funcionario> lista ) throws TomaraQueCaiaException {
		
		lista.addAll( Funcionario.listar( aplicacao ) );
		
	}
	
	protected void comandos() throws TomaraQueCaiaException {
		
		mais( cmdAdicionar );
		mais( cmdFechar );
		
	}
	
	protected void acao( Viagem viagem, Comando comando ) throws ValidacaoException, TomaraQueCaiaException {
		
		if( comando == cmdAdicionar ){
			
			viagem.visitar( new FuncionarioAdicaoFormulario( aplicacao ) );
			
		}else if( comando == cmdFechar ){
			
			sair( viagem );
			
		}
		
	}
	
	private class ColunaContrato extends ListaColunaPadrao<Funcionario> {
		
		public String getTitulo() {
			return "Contrato";
		}
		
		public Dado getDado( Funcionario elemento ) {
			return new Arquivo( null, new File( aplicacao.getLocalDocumentos(), elemento.getContrato() ), null, false );
		}
		
	}

	private class ColunaAcoes extends ListaColunaPadrao<Funcionario> {
		
		public String getTitulo() {
			return "A��es";
		}
		
		public List<Dado> getDados( Funcionario elemento ) {
			return new Lista<Dado>(
					new ComandoVisitar( "Editar", FuncionarioEdicaoFormulario.class, aplicacao, elemento ),
					new ComandoApagar( "Apagar Direto", aplicacao, elemento, "N�o foi poss�vel apagar o cadastro do funcion�rio porque h� refer�ncias a ele no sistema.", true ),
					new ComandoApagarQuestionando( elemento ),
					new ComandoFaltou( elemento )
			);
		}
		
	}
	
	private class ComandoApagarQuestionando extends ComandoQuestionamento<AloMundo> {

		private Funcionario elemento;
		
		public ComandoApagarQuestionando( Funcionario elemento ) {
			super( aplicacao, "Apagar Questionando", "Deseja realmente apagar o cadastro de \"" + elemento.getNome() + "\"?" );
			this.elemento = elemento;
		}

		@Override
		public void sim( AloMundo aplicacao, Viagem viagem ) throws TomaraQueCaiaException {
			try{
				aplicacao.remover( elemento, "N�o foi poss�vel apagar o cadastro do funcion�rio porque h� refer�ncias a ele no sistema.", true );
			}catch( Exception e ){
				throw new TomaraQueCaiaException( e );
			}finally{
				atualizar();
			}
		}
		
	}
	
	private class ComandoFaltou extends ComandoImplementado {

		private Funcionario elemento;
		
		public ComandoFaltou( Funcionario elemento ) {
			super( "Faltou" );
			this.elemento = elemento;
		}
		
		public void acao( Viagem viagem ) throws ValidacaoException, TomaraQueCaiaException {
			elemento.setFaltas( elemento.getFaltas() + 1 );
			aplicacao.persistirPendencias();
			atualizar();
		}
		
	}
	
}
