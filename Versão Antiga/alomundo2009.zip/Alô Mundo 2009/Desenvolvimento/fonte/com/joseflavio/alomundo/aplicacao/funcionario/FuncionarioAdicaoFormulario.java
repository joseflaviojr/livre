
/*
 *  Copyright (C) 2009 Jos� Fl�vio de Souza Dias J�nior
 *  
 *  This file is part of Jos� Fl�vio Livre - <http://www.joseflavio.com/livre/>.
 *  
 *  Jos� Fl�vio Livre is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *  
 *  Jos� Fl�vio Livre is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Jos� Fl�vio Livre. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.alomundo.aplicacao.funcionario;

import java.io.File;

import com.joseflavio.alomundo.Cargo;
import com.joseflavio.alomundo.Funcionario;
import com.joseflavio.alomundo.aplicacao.AloMundo;
import com.joseflavio.tqc.TomaraQueCaiaException;
import com.joseflavio.tqc.Viagem;
import com.joseflavio.tqc.aplicacao.Formulario;
import com.joseflavio.tqc.dado.Comando;
import com.joseflavio.util.Lista;
import com.joseflavio.validacao.ValidacaoException;

/**
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2009
 */
public class FuncionarioAdicaoFormulario extends Formulario<AloMundo> {

	private Comando cmdSalvar = new Comando( "Salvar" );
	private Comando cmdCancelar = new Comando( "Cancelar" );
	
	public FuncionarioAdicaoFormulario( AloMundo aplicacao ) throws TomaraQueCaiaException {
		
		super( aplicacao, "Novo Funcion�rio", "Novo Funcion�rio" );
		
		construir();
		
	}
	
	protected void campos() throws TomaraQueCaiaException {

		maisCampoTexto( "nome", Funcionario.class, "", true );
		maisCampoSelecao( "cargo", Funcionario.class, Cargo.values(), true );
		maisCampoData( "nascimento", Funcionario.class, null, true );
		maisCampoSelecao( "sexo", Funcionario.class, new String[]{ "Masculino", "Feminino" }, true );
		maisCampoSelecao( "gerente", Funcionario.class, new Lista<Funcionario>( null, Funcionario.listar( aplicacao, Cargo.GERENTE ) ), true );
		maisCampoReal( "salario", Funcionario.class, 0D, true );
		maisCampoInteiro( "faltas", Funcionario.class, 0L, true );
		maisCampoArquivo( "contrato", Funcionario.class, null, aplicacao.getLocalDocumentos(), true );
		maisCampoSenha( "senha", Funcionario.class, "", true );
		
	}
	
	protected void comandos() throws TomaraQueCaiaException {
		
		mais( cmdSalvar );
		mais( cmdCancelar );
		
	}
	
	protected void acao( Viagem viagem, Comando comando ) throws ValidacaoException, TomaraQueCaiaException {
		
		if( comando == cmdSalvar ){
			
			validarTudo();
			
			Funcionario funcionario = new Funcionario();
			funcionario.setNome( texto( "nome" ) );
			funcionario.setCargo( (Cargo) objeto( "cargo" ) );
			funcionario.setNascimento( data( "nascimento" ) );
			funcionario.setSexo( primitivoInt( "sexo" ) == 0 );
			funcionario.setGerente( (Funcionario) objeto( "gerente" ) );
			funcionario.setSalario( real( "salario" ) );
			funcionario.setFaltas( primitivoInt( "faltas" ) );
			funcionario.setContrato( ((File)objeto( "contrato" )).getName() );
			funcionario.setSenha( texto( "senha" ) );
			
			funcionario = aplicacao.persistir( funcionario );
			aplicacao.persistirPendencias();

			sair( viagem );
				
		}else if( comando == cmdCancelar ){
			
			sair( viagem );
			
		}
		
	}
	
}
