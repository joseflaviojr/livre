
/*
 *  Copyright (C) 2009 Jos� Fl�vio de Souza Dias J�nior
 *  
 *  This file is part of Jos� Fl�vio Livre - <http://www.joseflavio.com/livre/>.
 *  
 *  Jos� Fl�vio Livre is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *  
 *  Jos� Fl�vio Livre is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Jos� Fl�vio Livre. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.alomundo.aplicacao.autenticacao;

import com.joseflavio.alomundo.Funcionario;
import com.joseflavio.alomundo.aplicacao.AloMundo;
import com.joseflavio.tqc.Informacao;
import com.joseflavio.tqc.TomaraQueCaiaException;
import com.joseflavio.tqc.Viagem;
import com.joseflavio.tqc.aplicacao.Formulario;
import com.joseflavio.tqc.dado.Comando;
import com.joseflavio.validacao.ValidacaoException;

/**
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2009
 */
public class AutenticacaoFormulario extends Formulario<AloMundo> {
	
	private Informacao informacao;
	
	private Comando cmdCancelar = new Comando( "Cancelar" );
	private Comando cmdOk = new Comando( "Ok" );
	
	public AutenticacaoFormulario( AloMundo aplicacao, Informacao informacao ) throws TomaraQueCaiaException {
		
		super( aplicacao, "Autentica��o", "Autentica��o" );
		
		if( informacao == null ) throw new IllegalArgumentException();
		
		this.informacao = informacao;
		
		construir();
		
	}
	
	protected void campos() throws TomaraQueCaiaException {
		
		maisCampoInteiro( "id", Funcionario.class, null, true );
		maisCampoSenha( "senha", Funcionario.class, "", true );
		
	}

	protected void comandos() throws TomaraQueCaiaException {
		
		maisComando( cmdCancelar );
		maisComando( cmdOk );
		
	}

	protected void acao( Viagem viagem, Comando comando ) throws ValidacaoException, TomaraQueCaiaException {
		
		if( comando == cmdOk ){
			
			validarTudo();
			
			Funcionario usuario = Funcionario.obter( aplicacao, inteiro( "id" ) );
			
			if( usuario != null && usuario.getSenha().equals( texto( "senha" ) ) ){
				
				aplicacao.setUsuario( usuario );
				
				viagem.voltar();
				
			}else{
				
				setMensagemErro( "Matr�cula e/ou senha inv�lida." );
				
			}
			
		}else if( comando == cmdCancelar ){
			
			viagem.voltar();
			informacao.sair( viagem );
			
		}
		
	}
	
	public void sair( Viagem viagem ) {
	}
	
}
