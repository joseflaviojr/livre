
/*
 *  Copyright (C) 2009 Jos� Fl�vio de Souza Dias J�nior
 *  
 *  This file is part of Jos� Fl�vio Livre - <http://www.joseflavio.com/livre/>.
 *  
 *  Jos� Fl�vio Livre is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *  
 *  Jos� Fl�vio Livre is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Jos� Fl�vio Livre. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.alomundo.aplicacao;

import com.joseflavio.alomundo.Funcionario;
import com.joseflavio.alomundo.aplicacao.filtro.GerenteFiltro;
import com.joseflavio.alomundo.aplicacao.funcionario.FuncionarioEdicaoFormulario;
import com.joseflavio.alomundo.aplicacao.funcionario.FuncionarioListagem;
import com.joseflavio.tqc.Dado;
import com.joseflavio.tqc.TomaraQueCaiaException;
import com.joseflavio.tqc.Viagem;
import com.joseflavio.tqc.aplicacao.Formulario;
import com.joseflavio.tqc.dado.Comando;
import com.joseflavio.tqc.dado.Inteiro;
import com.joseflavio.tqc.dado.Marcador;
import com.joseflavio.tqc.dado.QuebraDeLinha;
import com.joseflavio.tqc.dado.Texto;
import com.joseflavio.validacao.ValidacaoException;

/**
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2009
 */
public class PrincipalFormulario extends Formulario<AloMundo> {

	private Comando cmdFuncionarios = new Comando( "Cadastro de Funcion�rios" );
	
	private Inteiro matricula = new Inteiro( "id", Funcionario.class, null, true );
	private Comando cmdAcessarFuncionario = new Comando( "Acessar" );
	
	private Comando cmdSairDoSistema = new Comando( "Sair do Sistema" );
	
	private Texto usuarioLogado = new Texto( "" );
	
	private Marcador marcadorGerenteInicio = new Marcador();
	private Marcador marcadorGerenteFim = new Marcador();
	
	public PrincipalFormulario( AloMundo aplicacao ) throws TomaraQueCaiaException {
		
		super( aplicacao, aplicacao.getTitulo(), aplicacao.getTitulo() );
		
		construir();
		
	}
	
	protected void antesDeMostrar( Viagem viagem ) throws TomaraQueCaiaException {
		
		setVisivel( GerenteFiltro.instancia.filtrar( aplicacao ), marcadorGerenteInicio, marcadorGerenteFim );

		Funcionario usuario = aplicacao.getUsuario();
		usuarioLogado.setTexto( usuario.getNome() + " (" + usuario.getCargo() + ")" );
		
	}
	
	protected void campos() throws TomaraQueCaiaException {

		mais( marcadorGerenteInicio );
		maisCampo( "Funcion�rios:", new Dado[]{ cmdFuncionarios, new QuebraDeLinha(), matricula, cmdAcessarFuncionario } );
		mais( marcadorGerenteFim );
		
		maisCampo( "Usu�rio:", usuarioLogado );
		
	}

	protected void comandos() throws TomaraQueCaiaException {
		
		maisComando( cmdSairDoSistema );
		
	}
	
	protected void acao( Viagem viagem, Comando comando ) throws ValidacaoException, TomaraQueCaiaException {
		
		if( comando == cmdFuncionarios ){
		
			aplicacao.novaViagem().visitar( new FuncionarioListagem( aplicacao ) ).ativar();
		
		}else if( comando == cmdAcessarFuncionario ){
			
			matricula.validar();
			
			Funcionario funcionario = Funcionario.obter( aplicacao, matricula.getNumero() );
			if( funcionario == null ){
				throw ValidacaoException.novaAtencao( "Cadastro n�o encontrado: " + matricula.getNumero() );
			}
			
			aplicacao.novaViagem().visitar( new FuncionarioEdicaoFormulario( aplicacao, funcionario ) ).ativar();
		
		}else if( comando == cmdSairDoSistema ){
			
			sair( viagem );
			
		}
		
	}
	
	public void sair( Viagem viagem ) {
		
		viagem.encerrar();
		
	}
	
}
