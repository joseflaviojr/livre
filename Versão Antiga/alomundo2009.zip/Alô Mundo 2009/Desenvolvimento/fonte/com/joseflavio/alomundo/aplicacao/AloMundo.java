
/*
 *  Copyright (C) 2009 Jos� Fl�vio de Souza Dias J�nior
 *  
 *  This file is part of Jos� Fl�vio Livre - <http://www.joseflavio.com/livre/>.
 *  
 *  Jos� Fl�vio Livre is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *  
 *  Jos� Fl�vio Livre is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Jos� Fl�vio Livre. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.alomundo.aplicacao;

import java.io.File;
import java.util.Calendar;
import java.util.Map;

import com.joseflavio.alomundo.Cargo;
import com.joseflavio.alomundo.Funcionario;
import com.joseflavio.alomundo.aplicacao.autenticacao.AutenticacaoFormulario;
import com.joseflavio.alomundo.aplicacao.filtro.ComOuSemUsuarioFiltro;
import com.joseflavio.alomundo.aplicacao.filtro.GerenteFiltro;
import com.joseflavio.alomundo.aplicacao.filtro.QualquerUsuarioFiltro;
import com.joseflavio.cultura.Cultura;
import com.joseflavio.tqc.Informacao;
import com.joseflavio.tqc.TomaraQueCaiaException;
import com.joseflavio.tqc.Viagem;
import com.joseflavio.tqc.aplicacao.AplicacaoTQC_JPA;
import com.joseflavio.tqc.aplicacao.Questionamento;
import com.joseflavio.util.Calendario;

/**
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2009
 */
public class AloMundo extends AplicacaoTQC_JPA {

	private Funcionario usuario;
	
	public AloMundo() {
		
		super( "Al� Mundo!", "alomundo", Cultura.BRASILEIRA );
	
		mais( AutenticacaoFormulario.class, ComOuSemUsuarioFiltro.instancia );
		mais( Questionamento.class, ComOuSemUsuarioFiltro.instancia );
		
		mais( "com.joseflavio.alomundo.aplicacao", QualquerUsuarioFiltro.instancia );
		
		mais( "com.joseflavio.alomundo.aplicacao.funcionario", GerenteFiltro.instancia );
		
	}
	
	public String getBanner() {
		return "img/banner.jpg";
	}
	
	public String getBannerPequeno() {
		return getBanner();
	}
	
	public void permissaoNegada( Viagem viagem, Informacao informacao ) throws TomaraQueCaiaException {
		viagem.visitar( new AutenticacaoFormulario( this, informacao ) );
	}
	
	public boolean negarAcessoSemFiltro() {
		return true;
	}
	
	public void inicio( Map<String, String> parametros ) throws TomaraQueCaiaException {
		
		if( Funcionario.listar( this ).size() == 0 ){
			
			Funcionario padrao = new Funcionario();
			padrao.setNome( "Jos� Fl�vio de Souza Dias J�nior" );
			padrao.setCargo( Cargo.GERENTE );
			padrao.setNascimento( new Calendario().setDia( 25 ).setMes( Calendar.APRIL ).setAno( 1985 ).getData() );
			padrao.setSexo( true );
			padrao.setGerente( null );
			padrao.setSalario( 1 );
			padrao.setFaltas( 0 );
			padrao.setContrato( "contrato.pdf" );
			padrao.setSenha( "1234" );
			
			padrao = persistir( padrao );
			persistirPendencias();
			
		}
		
		novaViagem().visitar( new PrincipalFormulario( this ) );
		
	}
	
	public Funcionario getUsuario() {
		return usuario;
	}
	
	public void setUsuario( Funcionario usuario ) {
		this.usuario = usuario;
	}
	
	public boolean isGerente() {
		return usuario != null ? usuario.getCargo() == Cargo.GERENTE : false;
	}
	
	public File getLocalDocumentos() {
		return new File( this.getRaiz(), "doc" );			
	}
	
}
