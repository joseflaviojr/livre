
/*
 *  Copyright (C) 2009 Jos� Fl�vio de Souza Dias J�nior
 *  
 *  This file is part of Jos� Fl�vio Livre - <http://www.joseflavio.com/livre/>.
 *  
 *  Jos� Fl�vio Livre is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *  
 *  Jos� Fl�vio Livre is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Jos� Fl�vio Livre. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.alomundo.aplicacao.funcionario;

import java.io.File;

import com.joseflavio.alomundo.Cargo;
import com.joseflavio.alomundo.Funcionario;
import com.joseflavio.alomundo.aplicacao.AloMundo;
import com.joseflavio.tqc.TomaraQueCaiaException;
import com.joseflavio.tqc.Viagem;
import com.joseflavio.tqc.aplicacao.Formulario;
import com.joseflavio.tqc.dado.Comando;
import com.joseflavio.util.Lista;
import com.joseflavio.validacao.ValidacaoException;

/**
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2009
 */
public class FuncionarioEdicaoFormulario extends Formulario<AloMundo> {

	private Funcionario funcionario;
	
	private Comando cmdSalvar = new Comando( "Salvar" );
	private Comando cmdCancelar = new Comando( "Cancelar" );
	
	public FuncionarioEdicaoFormulario( AloMundo aplicacao, Funcionario funcionario ) throws TomaraQueCaiaException {
		
		super( aplicacao, "Funcion�rio", "Funcion�rio" );
		
		this.funcionario = funcionario;
		
		construir();
		
	}
	
	protected void campos() throws TomaraQueCaiaException {

		maisCampoTexto( "nome", Funcionario.class, funcionario.getNome(), true );
		maisCampoSelecao( "cargo", Funcionario.class, Cargo.values(), funcionario.getCargo(), true );
		maisCampoData( "nascimento", Funcionario.class, funcionario.getNascimento(), true );
		maisCampoSelecao( "sexo", Funcionario.class, new String[]{ "Masculino", "Feminino" }, true ).setIndiceSelecionado( funcionario.isSexo() ? 0 : 1 );
		maisCampoSelecao( "gerente", Funcionario.class, new Lista<Funcionario>( null, Funcionario.listar( aplicacao, Cargo.GERENTE ) ), funcionario.getGerente(), true );
		maisCampoReal( "salario", Funcionario.class, funcionario.getSalario(), true );
		maisCampoInteiro( "faltas", Funcionario.class, (long) funcionario.getFaltas(), true );
		maisCampoArquivo( "contrato", Funcionario.class, new File( aplicacao.getLocalDocumentos(), funcionario.getContrato() ), aplicacao.getLocalDocumentos(), true );
		maisCampoSenha( "senha", Funcionario.class, funcionario.getSenha(), true );

	}
	
	protected void comandos() throws TomaraQueCaiaException {
		
		mais( cmdSalvar );
		mais( cmdCancelar );
		
	}
	
	protected void acao( Viagem viagem, Comando comando ) throws ValidacaoException, TomaraQueCaiaException {
		
		if( comando == cmdSalvar ){
			
			validarTudo();
			
			funcionario.setNome( texto( "nome" ) );
			funcionario.setCargo( (Cargo) objeto( "cargo" ) );
			funcionario.setNascimento( data( "nascimento" ) );
			funcionario.setSexo( primitivoInt( "sexo" ) == 0 );
			funcionario.setGerente( (Funcionario) objeto( "gerente" ) );
			funcionario.setSalario( real( "salario" ) );
			funcionario.setFaltas( primitivoInt( "faltas" ) );
			funcionario.setContrato( ((File)objeto( "contrato" )).getName() );
			funcionario.setSenha( texto( "senha" ) );
			
			aplicacao.persistirPendencias();

			sair( viagem );
				
		}else if( comando == cmdCancelar ){
			
			sair( viagem );
			
		}
		
	}
	
}
