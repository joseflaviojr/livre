
function selecionavelTextoEditar( dadoNome, rotulo ) {

var dado = document.getElementById( dadoNome );
var valor = prompt( rotulo, dado.value );

if( valor != null ){
	dado.options[0].text = valor;
	dado.options[0].value = valor;
	dado.selectedIndex = 0;
}

}