
/*
 *  Copyright (C) 2009 Jos� Fl�vio de Souza Dias J�nior
 *  
 *  This file is part of Jos� Fl�vio Livre - <http://www.joseflavio.com/livre/>.
 *  
 *  Jos� Fl�vio Livre is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *  
 *  Jos� Fl�vio Livre is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Jos� Fl�vio Livre. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.tqc.aplicacao;

import java.io.File;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.joseflavio.modelo.AssistenteDeAtributo;
import com.joseflavio.modelo.JFApresentacao;
import com.joseflavio.tqc.Dado;
import com.joseflavio.tqc.Estilo;
import com.joseflavio.tqc.Informacao;
import com.joseflavio.tqc.TomaraQueCaiaException;
import com.joseflavio.tqc.dado.Arquivo;
import com.joseflavio.tqc.dado.Bruto;
import com.joseflavio.tqc.dado.Comando;
import com.joseflavio.tqc.dado.Data;
import com.joseflavio.tqc.dado.Inteiro;
import com.joseflavio.tqc.dado.Real;
import com.joseflavio.tqc.dado.Selecao;
import com.joseflavio.tqc.dado.SelecionavelTexto;
import com.joseflavio.tqc.dado.Senha;
import com.joseflavio.tqc.dado.Tabela;
import com.joseflavio.tqc.dado.TabelaColuna;
import com.joseflavio.tqc.dado.TabelaColunaFim;
import com.joseflavio.tqc.dado.TabelaFim;
import com.joseflavio.tqc.dado.TabelaLinha;
import com.joseflavio.tqc.dado.TabelaLinhaFim;
import com.joseflavio.tqc.dado.Texto;

/**
 * {@link Informacao} com caracter�stica de formul�rio para entrada de {@link Dado}'s. 
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2009
 */
public abstract class Formulario<TQC extends AplicacaoTQC> extends BaseInformacao<TQC> {

	/**
	 * @see #construir()
	 */
	public Formulario( TQC aplicacao, String titulo, String banner, String subtitulo, boolean subtituloCentral ) throws TomaraQueCaiaException {
		
		super( aplicacao, titulo, banner, subtitulo, subtituloCentral );
		
		setAutoValidarTudo( false );
		
	}
	
	public Formulario( TQC aplicacao, String titulo, String subtitulo, boolean subtituloCentral ) throws TomaraQueCaiaException {
		this( aplicacao, titulo, null, subtitulo, subtituloCentral );
	}

	public Formulario( TQC aplicacao, String titulo, String banner, String subtitulo ) throws TomaraQueCaiaException {
		this( aplicacao, titulo, banner, subtitulo, false );
	}

	public Formulario( TQC aplicacao, String titulo, String subtitulo ) throws TomaraQueCaiaException {
		this( aplicacao, titulo, null, subtitulo, false );
	}

	protected void construir() throws TomaraQueCaiaException {
		
		super.construir();
		
		/*----------------------*/
		
		mais( new Tabela() );
		
		/*----------------------*/
		
		campos();
		
		/*----------------------*/
		
		mais( new TabelaLinha() );

		mais( new TabelaColuna() );
		mais( new TabelaColunaFim() );
		
		mais( new TabelaColuna() );
		mais( new TabelaColunaFim() );
		
		mais( new TabelaLinhaFim() );
		
		/*----------------------*/
		
		mais( new TabelaLinha() );

		mais( new TabelaColuna() );
		mais( new TabelaColunaFim() );
		
		mais( new TabelaColuna( "esquerda" ) );
		
		comandos();
		
		mais( new TabelaColunaFim() );
		
		mais( new TabelaLinhaFim() );
		
		/*----------------------*/
		
		mais( new TabelaFim() );
		
		/*----------------------*/
		
		rodape();
		
		/*----------------------*/
		
	}
	
	/**
	 * Deve executar {@link #maisCampo(String, Dado)} para cada campo desejado.
	 */
	protected abstract void campos() throws TomaraQueCaiaException;
	
	/**
	 * Deve executar {@link #maisComando(Comando)} para cada {@link Comando} desejado.
	 */
	protected abstract void comandos() throws TomaraQueCaiaException;
	
	/**
	 * Invocado depois de {@link #comandos()}. Esta implementa��o nada faz.
	 */
	protected void rodape() throws TomaraQueCaiaException {
	}
	
	protected final Formulario<TQC> maisCampo( String rotulo, Dado campo ){
		
		mais( new TabelaLinha() );

		mais( new TabelaColuna( Estilo.formColunaRotulo ) );
		mais( new Texto( rotulo ).setEstilo( Estilo.formRotulo ) );
		mais( new TabelaColunaFim() );
		
		mais( new TabelaColuna( Estilo.formColunaValor ) );
		mais( campo );
		mais( new TabelaColunaFim() );
		
		mais( new TabelaLinhaFim() );
		
		return this;
		
	}
	
	protected final Formulario<TQC> maisCampo( String rotulo, String valor ){
		
		return maisCampo( rotulo, new Texto( valor ) );
		
	}

	public static String getApresentacao( Class<? extends Object> classe, String atributo ) {
		JFApresentacao jfApresentacao = AssistenteDeAtributo.getAnotacao( classe, atributo, JFApresentacao.class, false );
		return jfApresentacao != null ? jfApresentacao.value() : atributo;
	}
	
	public static String getRotulo( Class<? extends Object> classe, String atributo ) {
		JFApresentacao jfApresentacao = AssistenteDeAtributo.getAnotacao( classe, atributo, JFApresentacao.class, false );
		return ( jfApresentacao != null ? jfApresentacao.value() : atributo ) + ":";
	}
	
	public static Texto getRotuloFormatado( Class<? extends Object> classe, String atributo ) {
		return (Texto) new Texto( getRotulo( classe, atributo ) ).setEstilo( Estilo.formRotulo );
	}
	
	public static Texto getRotulo( String texto ) {
		return (Texto) new Texto( texto ).setEstilo( Estilo.formRotulo );
	}
	
	protected Texto maisCampoTexto( String nome, Class<? extends Object> classe, String atributo, String texto, Boolean editavel ) {
		Texto dado = new Texto( nome, classe, atributo, texto, editavel );
		maisCampo( getRotulo( classe, atributo ), dado );
		return dado;
	}
	
	protected Texto maisCampoTexto( String nome, Class<? extends Object> classe, String texto, Boolean editavel ) {
		return maisCampoTexto( nome, classe, nome, texto, editavel );
	}
	
	protected Senha maisCampoSenha( String nome, Class<? extends Object> classe, String atributo, String senha, Boolean editavel ) {
		Senha dado = new Senha( nome, classe, atributo, senha, editavel );
		maisCampo( getRotulo( classe, atributo ), dado );
		return dado;
	}
	
	protected Senha maisCampoSenha( String nome, Class<? extends Object> classe, String senha, Boolean editavel ) {
		return maisCampoSenha( nome, classe, nome, senha, editavel );
	}
	
	protected Data maisCampoData( String nome, Class<? extends Object> classe, String atributo, Date data, Boolean editavel ) {
		Data dado = new Data( nome, classe, atributo, data, editavel );
		maisCampo( getRotulo( classe, atributo ), dado );
		return dado;
	}
	
	protected Data maisCampoData( String nome, Class<? extends Object> classe, Date data, Boolean editavel ) {
		return maisCampoData( nome, classe, nome, data, editavel );
	}
	
	protected Real maisCampoReal( String nome, Class<? extends Object> classe, String atributo, Double numero, Boolean editavel ) {
		Real dado = new Real( nome, classe, atributo, numero, editavel );
		maisCampo( getRotulo( classe, atributo ), dado );
		return dado;
	}
	
	protected Real maisCampoReal( String nome, Class<? extends Object> classe, Double numero, Boolean editavel ) {
		return maisCampoReal( nome, classe, nome, numero, editavel );
	}
	
	protected Inteiro maisCampoInteiro( String nome, Class<? extends Object> classe, String atributo, Long numero, Boolean editavel ) {
		Inteiro dado = new Inteiro( nome, classe, atributo, numero, editavel );
		maisCampo( getRotulo( classe, atributo ), dado );
		return dado;
	}
	
	protected Inteiro maisCampoInteiro( String nome, Class<? extends Object> classe, Long numero, Boolean editavel ) {
		return maisCampoInteiro( nome, classe, nome, numero, editavel );
	}
	
	protected <T extends Object> Selecao<T> maisCampoSelecao( String nome, Class<? extends Object> classe, String atributo, List<T> opcoes, T selecaoInicial, Boolean editavel ) {
		Selecao<T> dado = new Selecao<T>( nome, classe, atributo, opcoes, selecaoInicial, editavel );
		maisCampo( getRotulo( classe, atributo ), dado );
		return dado;
	}
	
	protected <T extends Object> Selecao<T> maisCampoSelecao( String nome, Class<? extends Object> classe, List<T> opcoes, T selecaoInicial, Boolean editavel ) {
		return maisCampoSelecao( nome, classe, nome, opcoes, selecaoInicial, editavel );
	}
	
	protected <T extends Object> Selecao<T> maisCampoSelecao( String nome, Class<? extends Object> classe, List<T> opcoes, Boolean editavel ) {
		return maisCampoSelecao( nome, classe, opcoes, null, editavel );
	}
	
	protected <T extends Object> Selecao<T> maisCampoSelecao( String nome, Class<? extends Object> classe, String atributo, T[] opcoes, T selecaoInicial, Boolean editavel ) {
		return maisCampoSelecao( nome, classe, atributo, Arrays.asList( opcoes ), selecaoInicial, editavel );
	}
	
	protected <T extends Object> Selecao<T> maisCampoSelecao( String nome, Class<? extends Object> classe, T[] opcoes, T selecaoInicial, Boolean editavel ) {
		return maisCampoSelecao( nome, classe, nome, Arrays.asList( opcoes ), selecaoInicial, editavel );
	}
	
	protected <T extends Object> Selecao<T> maisCampoSelecao( String nome, Class<? extends Object> classe, T[] opcoes, Boolean editavel ) {
		return maisCampoSelecao( nome, classe, nome, Arrays.asList( opcoes ), null, editavel );
	}
	
	protected SelecionavelTexto maisCampoSelecionavelTexto( String nome, Class<? extends Object> classe, String atributo, String texto, List<String> opcoes, Boolean editavel ) {
		SelecionavelTexto dado = new SelecionavelTexto( nome, classe, atributo, texto, opcoes, editavel );
		maisCampo( getRotulo( classe, atributo ), dado );
		return dado;
	}
	
	protected SelecionavelTexto maisCampoSelecionavelTexto( String nome, Class<? extends Object> classe, String atributo, String texto, String[] opcoes, Boolean editavel ) {
		return maisCampoSelecionavelTexto( nome, classe, atributo, texto, Arrays.asList( opcoes ), editavel );
	}
	
	protected SelecionavelTexto maisCampoSelecionavelTexto( String nome, Class<? extends Object> classe, String texto, List<String> opcoes, Boolean editavel ) {
		return maisCampoSelecionavelTexto( nome, classe, nome, texto, opcoes, editavel );
	}
	
	protected SelecionavelTexto maisCampoSelecionavelTexto( String nome, Class<? extends Object> classe, String texto, String[] opcoes, Boolean editavel ) {
		return maisCampoSelecionavelTexto( nome, classe, nome, texto, Arrays.asList( opcoes ), editavel );
	}
	
	protected Bruto maisCampoBruto( String nome, Class<? extends Object> classe, String atributo, byte[] valor, String valorRotulo, Boolean editavel ) {
		Bruto dado = new Bruto( nome, classe, atributo, valor, valorRotulo, editavel );
		maisCampo( getRotulo( classe, atributo ), dado );
		return dado;
	}
	
	protected Bruto maisCampoBruto( String nome, Class<? extends Object> classe, byte[] valor, String valorRotulo, Boolean editavel ) {
		return maisCampoBruto( nome, classe, nome, valor, valorRotulo, editavel );
	}
	
	protected Arquivo maisCampoArquivo( String nome, Class<? extends Object> classe, String atributo, File arquivo, File localPreferido, Boolean editavel ) {
		Arquivo dado = new Arquivo( nome, classe, atributo, arquivo, localPreferido, editavel );
		maisCampo( getRotulo( classe, atributo ), dado );
		return dado;
	}
	
	protected Arquivo maisCampoArquivo( String nome, Class<? extends Object> classe, File arquivo, File localPreferido, Boolean editavel ) {
		return maisCampoArquivo( nome, classe, nome, arquivo, localPreferido, editavel );
	}
	
	protected final Formulario<TQC> maisCampo( String rotulo, Dado[] dadosDoCampo ){
		
		return maisCampo( rotulo, Arrays.asList( dadosDoCampo ) );
		
	}
	
	protected final Formulario<TQC> maisCampo( String rotulo, List<? extends Dado> dadosDoCampo ){
		
		mais( new TabelaLinha() );

		mais( new TabelaColuna( Estilo.formColunaRotulo ) );
		mais( new Texto( rotulo ).setEstilo( Estilo.formRotulo ) );
		mais( new TabelaColunaFim() );
		
		mais( new TabelaColuna( Estilo.formColunaValor ) );
		for( Dado d : dadosDoCampo ) mais( d );
		mais( new TabelaColunaFim() );
		
		mais( new TabelaLinhaFim() );
		
		return this;
		
	}
	
	protected final Formulario<TQC> maisComando( Comando comando ){

		comando.setEspacoTextualPosterior( true );
		mais( (Dado) comando );
		
		return this;
		
	}
	
}
