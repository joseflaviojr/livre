
/*
 *  Copyright (C) 2009 Jos� Fl�vio de Souza Dias J�nior
 *  
 *  This file is part of Jos� Fl�vio Livre - <http://www.joseflavio.com/livre/>.
 *  
 *  Jos� Fl�vio Livre is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *  
 *  Jos� Fl�vio Livre is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Jos� Fl�vio Livre. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.tqc.dado;

import java.lang.reflect.Field;

import com.joseflavio.modelo.JFAcesso;
import com.joseflavio.modelo.JFApresentacao;
import com.joseflavio.modelo.JFValidacaoNaoNulo;
import com.joseflavio.modelo.JFValidacaoPrimitiva;
import com.joseflavio.tqc.ComplexoDado;
import com.joseflavio.validacao.NaoNuloValidacao;
import com.joseflavio.validacao.ValidacaoException;

/**
 * {@link Boolean}.
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2009
 */
public class Binario extends ComplexoDado {

	private String rotulo;
	
	private Boolean valor;
	
	/**
	 * @param valor Conte�do. Pode ser <code>null</code>.
	 */
	public Binario( String nome, String rotulo, Boolean valor, boolean editavel ) {
		super( nome, editavel );
		this.rotulo = rotulo;
		this.valor = valor;
	}
	
	public Binario( String nome, Class<? extends Object> classe, String atributo, Boolean valor, Boolean editavel ) {
		
		super( nome );
		
		Field alvo;
		try{
			alvo = classe.getDeclaredField( atributo );
		}catch( Exception e ){
			throw new IllegalArgumentException( "Atributo " + classe.getName() + "." + atributo + " desconhecido." ); 
		}
		
		JFApresentacao         jfApresentacao         = alvo.getAnnotation( JFApresentacao.class );
		JFAcesso               jfAcesso               = alvo.getAnnotation( JFAcesso.class );
		JFValidacaoPrimitiva   jfValidacaoPrimitiva   = alvo.getAnnotation( JFValidacaoPrimitiva.class );
		JFValidacaoNaoNulo     jfValidacaoNaoNulo     = alvo.getAnnotation( JFValidacaoNaoNulo.class );

		this.valor = valor;
		
		if( jfApresentacao != null ) this.rotulo = jfApresentacao.value();
		if( jfAcesso != null ){
			setVisivel( jfAcesso.visivel() );
			setEditavel( jfAcesso.editavel() );
		}
		if( jfValidacaoPrimitiva != null ) maisValidacaoPrimitiva( jfValidacaoPrimitiva.erro() );
		if( jfValidacaoNaoNulo != null ) maisNaoNulo( jfValidacaoNaoNulo.erro() );
		
		if( editavel != null ) setEditavel( editavel );
		
	}
	
	public Binario( String nome, Class<? extends Object> classe, Boolean valor, Boolean editavel ) {
		
		this( nome, classe, nome, valor, editavel );
		
	}
	
	public Object getConteudo() {
		return valor;
	}
	
	public Boolean getValorValidado() throws ValidacaoException {
		validar();
		return valor;
	}
	
	public Boolean getValor() {
		return valor;
	}
	
	public Binario setValor( Boolean valor ) {
		this.valor = valor;
		return this;
	}
	
	public boolean isVerdadeiro() {
		return valor != null && valor == true;
	}
	
	public String getRotulo() {
		return rotulo;
	}
	
	public Binario setRotulo( String rotulo ) {
		this.rotulo = rotulo;
		return this;
	}
	
	public Binario maisValidacaoPrimitiva( String mensagem ) {
		setMensagemValidacaoPrimitiva( mensagem );
		return this;
	}
	
	public Binario maisNaoNulo( int tipo, String mensagem ) {
		mais( new NaoNuloValidacao( getNome(), tipo, mensagem ) );
		return this;
	}
	
	public Binario maisNaoNulo( String mensagem ) {
		return maisNaoNulo( ValidacaoException.ERRO, mensagem );
	}
	
}
