
/*
 *  Copyright (C) 2009 Jos� Fl�vio de Souza Dias J�nior
 *  
 *  This file is part of Jos� Fl�vio Livre - <http://www.joseflavio.com/livre/>.
 *  
 *  Jos� Fl�vio Livre is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *  
 *  Jos� Fl�vio Livre is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Jos� Fl�vio Livre. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.dominio.simulacao;

import java.util.HashMap;
import java.util.Map;

import com.joseflavio.dominio.Dominio;
import com.joseflavio.dominio.DominioException;
import com.joseflavio.dominio.DominioUsuario;

/**
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2009
 */
public class SimulacaoDominio extends Dominio {

	private String nome;
	
	private String endereco;
	
	private SimulacaoUsuario usuario;
	
	private Map<String, SimulacaoUsuario> usuarios = new HashMap<String, SimulacaoUsuario>();
	
	public SimulacaoDominio( String nome, String endereco, SimulacaoUsuario usuario ) throws DominioException {

		this.nome = nome;
		this.endereco = endereco;
		this.usuario = usuario;
		
		mais( usuario );
		
	}
	
	public SimulacaoDominio mais( SimulacaoUsuario usuario ) {
		
		usuarios.put( usuario.getIdentificacao(), usuario );
		
		return this;
		
	}
	
	public boolean isDisponivel() {
		
		return true;
		
	}
	
	public DominioUsuario buscarUsuario( String identificacao, String baseBusca ) throws DominioException {
		return buscarUsuario( identificacao );
	}
	
	public DominioUsuario buscarUsuario( String identificacao ) throws DominioException {
		SimulacaoUsuario u = usuarios.get( identificacao );
		if( u == null ) throw new DominioException();
		return u;
	}
	
	public DominioUsuario autenticarUsuario( String identificacao, String senha ) throws DominioException {
		
		SimulacaoUsuario u = usuarios.get( identificacao );
		if( u == null ) throw new DominioException();
		
		String s = u.getSenha();
		if( s == null || senha == null || ! s.equals( senha ) ) throw new DominioException();
		
		return u;
		
	}
	
	public String getEndereco() {
		return endereco;
	}

	public String getNome() {
		return nome;
	}

	public DominioUsuario getUsuario() {
		return usuario;
	}

}
