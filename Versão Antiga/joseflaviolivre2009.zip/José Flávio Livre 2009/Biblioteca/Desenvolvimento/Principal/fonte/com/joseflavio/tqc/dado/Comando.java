
/*
 *  Copyright (C) 2009 Jos� Fl�vio de Souza Dias J�nior
 *  
 *  This file is part of Jos� Fl�vio Livre - <http://www.joseflavio.com/livre/>.
 *  
 *  Jos� Fl�vio Livre is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *  
 *  Jos� Fl�vio Livre is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Jos� Fl�vio Livre. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.tqc.dado;

import com.joseflavio.tqc.Dado;
import com.joseflavio.tqc.EspacoLateral;
import com.joseflavio.tqc.Identificacao;
import com.joseflavio.tqc.SimplesDado;

/**
 * Um comando induz uma a��o, mas n�o a especifica.
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2009
 */
public class Comando extends SimplesDado implements Identificacao, EspacoLateral {
	
	/**
	 * Fun��o normal.
	 */
	public static final int NORMAL = 1;
	
	/**
	 * Fun��o de confirma��o.
	 */
	public static final int OK = 2;
	
	/**
	 * Fun��o de cancelamento.
	 */
	public static final int CANCELAMENTO = 3;
	
	/**
	 * Fun��o de avan�o.
	 */
	public static final int SUCESSAO = 4;
	
	/**
	 * Fun��o de retorno.
	 */
	public static final int ANTECESSAO = 5;
	
	private String nome;
	
	private String rotulo;
	
	private String imagem;
	
	private int funcao = NORMAL;
	
	private boolean espacoTextualPosterior = false;
	
	/**
	 * @param rotulo R�tulo que define o {@link Comando}.
	 * @param funcao Fun��o gen�rica do {@link Comando}.
	 */
	public Comando( String nome, String rotulo, String imagem, int funcao ) {
		this.nome = nome;
		this.rotulo = rotulo;
		this.imagem = imagem;
		this.funcao = funcao;
	}
	
	public Comando( String nome, String rotulo, int funcao ) {
		this( nome, rotulo, null, funcao );
	}
	
	public Comando( String nome, String rotulo ) {
		this( nome, rotulo, null, NORMAL );
	}
	
	public Comando( String rotulo ) {
		this( null, rotulo, null, NORMAL );
	}
	
	public String getNome() {
		return nome;
	}
	
	public Dado setNome( String nome ) {
		this.nome = nome;
		return this;
	}
	
	public Object getConteudo() {
		return rotulo;
	}
	
	public String getRotulo() {
		return rotulo;
	}
	
	public Comando setRotulo( String rotulo ) {
		this.rotulo = rotulo;
		return this;
	}
	
	public String getImagem() {
		return imagem;
	}
	
	public Comando setImagem( String imagem ) {
		this.imagem = imagem;
		return this;
	}
	
	public int getFuncao() {
		return funcao;
	}
	
	public Comando setFuncao( int funcao ) {
		this.funcao = funcao;
		return this;
	}
	
	public boolean isEspacoTextualPosterior() {
		return espacoTextualPosterior;
	}
	
	public Dado setEspacoTextualPosterior( boolean sim ) {
		this.espacoTextualPosterior = sim;
		return this;
	}
	
}
