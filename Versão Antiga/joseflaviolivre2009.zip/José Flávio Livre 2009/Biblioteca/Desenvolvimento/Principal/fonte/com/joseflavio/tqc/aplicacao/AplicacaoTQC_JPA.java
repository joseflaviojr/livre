
/*
 *  Copyright (C) 2009 Jos� Fl�vio de Souza Dias J�nior
 *  
 *  This file is part of Jos� Fl�vio Livre - <http://www.joseflavio.com/livre/>.
 *  
 *  Jos� Fl�vio Livre is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *  
 *  Jos� Fl�vio Livre is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Jos� Fl�vio Livre. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.tqc.aplicacao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.joseflavio.cultura.Cultura;
import com.joseflavio.jpa.JPAUtil;
import com.joseflavio.jpa.PersistenceUnit;
import com.joseflavio.jpa.PersistenceXML;
import com.joseflavio.tqc.EstiloFonte;
import com.joseflavio.validacao.ValidacaoException;

/**
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2009
 */
public abstract class AplicacaoTQC_JPA extends AplicacaoTQC {

	private String persistenceUnitName;

	private PersistenceUnit persistenceUnit;
	
	private EntityManagerFactory entityManagerFactory;
	
	private EntityManager entityManager;
	
	private EntityTransaction entityTransaction;
	
	private boolean autoDestacar = false;
	
	public AplicacaoTQC_JPA( String titulo, String persistenceUnitName, Cultura cultura, EstiloFonte estiloFonte ) {
		
		super( titulo, cultura, estiloFonte );
		
		this.persistenceUnitName = persistenceUnitName;
		
	}
	
	public AplicacaoTQC_JPA( String titulo, String persistenceUnitName, Cultura cultura ) {
		
		this( titulo, persistenceUnitName, cultura, null );
		
	}
	
	public synchronized PersistenceUnit getPersistenceUnit() throws BancoDeDadosException {
		
		try{
		
			if( persistenceUnit == null ){
				persistenceUnit = new PersistenceXML().getPersistenceUnit( persistenceUnitName );
			}
			
			return persistenceUnit;
			
		}catch( Exception e ){
			throw new BancoDeDadosException( e );
		}
		
	}
	
	public synchronized EntityManagerFactory getEntityManagerFactory() throws BancoDeDadosException {
		
		try{
		
			if( entityManagerFactory == null ){
				entityManagerFactory = Persistence.createEntityManagerFactory( persistenceUnitName );
			}
			
			return entityManagerFactory;
			
		}catch( Exception e ){
			throw new BancoDeDadosException( e );
		}
		
	}
	
	public synchronized EntityManager getEntityManager() throws BancoDeDadosException {
		
		try{
			
			if( entityManager == null || ! entityManager.isOpen() ){
				
				entityManager = getEntityManagerFactory().createEntityManager();
				entityTransaction = entityManager.getTransaction();
				entityTransaction.begin();
				
			}
			
			return entityManager;
		
		}catch( BancoDeDadosException e ){
			throw e;
		}catch( Exception e ){
			throw new BancoDeDadosException( e );
		}
		
	}
	
	public synchronized void persistirPendencias() throws BancoDeDadosException {
		
		try{

			if( entityTransaction != null && entityTransaction.isActive() ){
				entityTransaction.commit();
				entityTransaction.begin();
			}
			
		}catch( Exception e ){
			throw new BancoDeDadosException( e );
		}
		
	}
	
	public synchronized void fecharEntityManagerFactory() {
		
		try{
			if( entityManagerFactory != null && entityManagerFactory.isOpen() ) entityManagerFactory.close();
		}catch( Exception e ){
		}finally{
			entityManagerFactory = null;
		}
		
	}
	
	public synchronized void fecharEntityManager() {
		
		try{
			if( entityTransaction != null && entityTransaction.isActive() ) entityTransaction.commit();
		}catch( Exception e ){
		}finally{
			entityTransaction = null;
		}
		
		try{
			if( entityManager != null && entityManager.isOpen() ) entityManager.close();
		}catch( Exception e ){
		}finally{
			entityManager = null;
		}
		
	}
	
	public synchronized void fecharBancoDeDados() {
		
		fecharEntityManager();
		fecharEntityManagerFactory();
		
	}
	
	public void fim() {
		
		fecharBancoDeDados();
		
	}
	
	public <T extends Object> T persistir( T obj ) {
		
		EntityManager em = getEntityManager();
		
		if( autoDestacar ){
			obj = em.merge( obj );
			persistirPendencias();
			return JPAUtil.destacar( em, obj );
		}
		
		em.persist( obj );
		return obj;
		
	}
	
	/**
	 * Remove um objeto do banco de dados caso outro objeto n�o dependa de sua exist�ncia.
	 * @param obj Objeto a ser removido do banco de dados.
	 * @param msgDependencia Mensagem para {@link ValidacaoException}.
	 * @throws ValidacaoException caso outro objeto dependa da exist�ncia do que seria removido.
	 */
	public void remover( Object obj, String msgDependencia, boolean persistirPendencias ) throws ValidacaoException, BancoDeDadosException {
		
		EntityManager em = getEntityManager();
		
		if( autoDestacar ) obj = em.merge( obj );
		
		if( getPersistenceUnit().temReferencia( em, obj ) ){
			throw ValidacaoException.novaAtencao( msgDependencia );
		}
		
		em.remove( obj );
		if( persistirPendencias ) persistirPendencias();
		
	}
	
	public <T extends Object> List<T> listar( String query, int resultadoInicial, int maximoResultados, Object... parametros ) {
		List<T> lista = JPAUtil.listar( this, query, resultadoInicial, maximoResultados, parametros );
		return autoDestacar && lista != null ? JPAUtil.destacar( this, lista ) : lista;
	}
	
	public <T extends Object> List<T> listar( String query, Object... parametros ) {
		List<T> lista = JPAUtil.listar( this, query, parametros );
		return autoDestacar && lista != null ? JPAUtil.destacar( this, lista ) : lista;
	}
	
	public <T extends Object> T obter( String query, Object... parametros ) {
		T obj = JPAUtil.obter( this, query, parametros );
		return autoDestacar && obj != null ? JPAUtil.destacar( this, obj ) : obj;
	}
	
	public long obterQuantidade( String query, Object... parametros ) {
		return JPAUtil.obterQuantidade( this, query, parametros );
	}
	
	public Number obterNumero( String query, Object... parametros ) {
		return JPAUtil.obterNumero( this, query, parametros );
	}
	
	/**
	 * @see EntityManager#detach(Object)
	 * @see JPAUtil#destacar(AplicacaoTQC_JPA, Object)
	 */
	public void setAutoDestacar( boolean autoDestacar ) {
		this.autoDestacar = autoDestacar;
	}
	
	public boolean isAutoDestacar() {
		return autoDestacar;
	}
	
}
