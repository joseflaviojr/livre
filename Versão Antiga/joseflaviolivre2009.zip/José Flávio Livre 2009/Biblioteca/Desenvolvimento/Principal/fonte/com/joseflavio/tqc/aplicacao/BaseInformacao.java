
/*
 *  Copyright (C) 2009 Jos� Fl�vio de Souza Dias J�nior
 *  
 *  This file is part of Jos� Fl�vio Livre - <http://www.joseflavio.com/livre/>.
 *  
 *  Jos� Fl�vio Livre is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *  
 *  Jos� Fl�vio Livre is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Jos� Fl�vio Livre. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.tqc.aplicacao;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import com.joseflavio.tqc.Alerta;
import com.joseflavio.tqc.Informacao;
import com.joseflavio.tqc.TomaraQueCaia;
import com.joseflavio.tqc.TomaraQueCaiaException;
import com.joseflavio.tqc.Viagem;
import com.joseflavio.tqc.dado.Comando;
import com.joseflavio.tqc.dado.Imagem;
import com.joseflavio.tqc.dado.Marcador;
import com.joseflavio.tqc.dado.Texto;
import com.joseflavio.validacao.ValidacaoException;

/**
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2009
 */
public abstract class BaseInformacao<T extends AplicacaoTQC> extends Informacao {

	public static final String ESTILO_SUBTITULO = "formSubtitulo";
	public static final String ESTILO_MENSAGEM_ERRO = "formMensagemErro";
	public static final String ESTILO_MENSAGEM_INFORMACAO = "formMensagemInformacao";
	
	protected T aplicacao;
	
	private Imagem banner = new Imagem( null );
	private Marcador marcadorBannerInicio = new Marcador();
	private Marcador marcadorBannerFim = new Marcador();
	
	private Texto mensagemErro = (Texto) new Texto( null ).setEstilo( ESTILO_MENSAGEM_ERRO );
	private Marcador marcadorMensagemErroInicio = new Marcador();
	private Marcador marcadorMensagemErroFim = new Marcador();
	
	
	private Texto mensagemInformacao = (Texto) new Texto( null ).setEstilo( ESTILO_MENSAGEM_INFORMACAO );
	private Marcador marcadorMensagemInformacaoInicio = new Marcador();
	private Marcador marcadorMensagemInformacaoFim = new Marcador();
	
	private Texto subtitulo = (Texto) new Texto( null ).setEstilo( ESTILO_SUBTITULO );
	private Marcador marcadorSubtituloInicio = new Marcador();
	private Marcador marcadorSubtituloFim = new Marcador();
	
	private boolean autoRetirarMensagens = true;
	
	private boolean autoValidarTudo = false;
	
	private boolean autoCriarAlerta = false;
	
	private boolean buscarMetodoDeComando = true;
	
	private boolean subtituloCentral = false;
	
	/**
	 * @see #construir()
	 */
	public BaseInformacao( T aplicacao, String titulo, String banner, String subtitulo, boolean subtituloCentral ) throws TomaraQueCaiaException {
		
		super( titulo );
		
		this.aplicacao = aplicacao;
		
		this.subtitulo.setTexto( subtitulo );
		this.subtituloCentral = subtituloCentral;

		if( banner == null ) banner = aplicacao.getBanner();
		this.banner.setUrl( banner );
		
	}
	
	public BaseInformacao( T aplicacao, String titulo, String banner, String subtitulo ) throws TomaraQueCaiaException {
		this( aplicacao, titulo, banner, subtitulo, false );
	}
	
	public BaseInformacao( T aplicacao, String titulo, String subtitulo, boolean subtituloCentral ) throws TomaraQueCaiaException {
		this( aplicacao, titulo, null, subtitulo, subtituloCentral );
	}
	
	public BaseInformacao( T aplicacao, String titulo, String subtitulo ) throws TomaraQueCaiaException {
		this( aplicacao, titulo, null, subtitulo, false );
	}
	
	/**
	 * Efetua a constru��o da {@link Informacao}.
	 */
	protected void construir() throws TomaraQueCaiaException {
		
		/*----------------------*/
		
		mais( marcadorBannerInicio );
		maisLinha( "centroH" );
		
		mais( banner );
		
		maisLinhaFim();
		mais( marcadorBannerFim );
		
		/*----------------------*/
		
		mais( marcadorSubtituloInicio );
		maisLinha( subtituloCentral ? "centroH" : "esquerda" );
		
		mais( subtitulo );
		
		maisLinhaFim();
		maisQuebraDeLinha();
		mais( marcadorSubtituloFim );
		
		/*----------------------*/
		
		cabecalho();
		
		/*----------------------*/
		
		mais( marcadorMensagemErroInicio );
		maisQuebraDeLinha();
		maisLinha( "centroH" );
		
		mais( mensagemErro );
		
		maisLinhaFim();
		maisQuebraDeLinha();
		mais( marcadorMensagemErroFim );
		
		/*----------------------*/
		
		mais( marcadorMensagemInformacaoInicio );
		maisQuebraDeLinha();
		maisLinha( "centroH" );
		
		mais( mensagemInformacao );
		
		maisLinhaFim();
		maisQuebraDeLinha();
		mais( marcadorMensagemInformacaoFim );
		
		/*----------------------*/
		
	}
	
	/**
	 * Invocado depois do banner e do subt�tulo, e antes das mensagens de erro e informa��o.<br>
	 * Esta implementa��o nada faz.
	 */
	protected void cabecalho() throws TomaraQueCaiaException {
	}
	
	public final void antesDeMostrar( TomaraQueCaia tqc, Viagem viagem ) throws TomaraQueCaiaException {

		this.antesDeMostrar( viagem );
		
		setVisivel( subtitulo.getTexto() != null && subtitulo.getTexto().length() > 0, marcadorSubtituloInicio, marcadorSubtituloFim );
		setVisivel( banner.getUrl() != null, marcadorBannerInicio, marcadorBannerFim );
		setVisivel( mensagemErro.getTexto() != null, marcadorMensagemErroInicio, marcadorMensagemErroFim );
		setVisivel( mensagemInformacao.getTexto() != null, marcadorMensagemInformacaoInicio, marcadorMensagemInformacaoFim );
		
		if( autoCriarAlerta ){
			Alerta alerta = criarAlerta();
			if( alerta != null ) viagem.mostrar( alerta );
		}
		
	}
	
	protected void antesDeMostrar( Viagem viagem ) throws TomaraQueCaiaException {
	}
	
	public final void acao( TomaraQueCaia tqc, Viagem viagem, Comando comando ) throws TomaraQueCaiaException {

		if( autoRetirarMensagens ) retirarMensagens();
		
		try{
			
			if( autoValidarTudo ) validarTudo();
			
			if( comando instanceof ComandoImplementado ){
				
				((ComandoImplementado)comando).acao( viagem );
			
			}else if( buscarMetodoDeComando && comando.getNome() != null ){
				
				try{
					
					this.getClass().getDeclaredMethod( comando.getNome(), Viagem.class, Comando.class ).invoke( this, viagem, comando );
				
				}catch( InvocationTargetException e ){
					throw (Exception) e.getCause();
				}catch( NoSuchMethodException e ){
					acao( viagem, comando );
				}catch( SecurityException e ){
					acao( viagem, comando );
				}
					
			}else{
				
				acao( viagem, comando );
				
			}
			
		}catch( ValidacaoException e ){
			
			switch( e.getTipo() ){
				
				case ValidacaoException.INFORMACAO :
					setMensagemInformacao( e.getMensagem() );
					break;
					
				default :
					setMensagemErro( e.getMensagem() );
					break;
				
			}
		
		}catch( TomaraQueCaiaException e ){
			
			throw e;
			
		}catch( BancoDeDadosException e ){
			
			e.printStackTrace();
			setMensagemErro( "Erro de Banco de Dados: " + e.getMessage() );
			
		}catch( Exception e ){
			
			e.printStackTrace();
			setMensagemErro( "Erro desconhecido: " + e.getMessage() );
			
		}
		
	}
	
	/**
	 * @throws ValidacaoException ser� convertida em {@link #setMensagemErro(String)} ou {@link #setMensagemInformacao(String)}.
	 * @throws IOException ser� convertida em {@link #setMensagemErro(String)} como erro desconhecido.
	 * @throws TomaraQueCaiaException ser� propagada.
	 */
	protected abstract void acao( Viagem viagem, Comando comando ) throws ValidacaoException, TomaraQueCaiaException;
	
	public void setSubtitulo( String subtitulo ) {
		this.subtitulo.setTexto( subtitulo );
	}
	
	public String getSubtitulo() {
		return subtitulo.getTexto();
	}
	
	public void setBanner( String imagem ) {
		banner.setUrl( imagem );
	}
	
	public String getBanner() {
		return banner.getUrl();
	}
	
	public void retirarMensagens() {
		setMensagemErro( null );
		setMensagemInformacao( null );
	}
	
	public void setMensagemErro( String texto ) {
		mensagemErro.setTexto( texto );
	}
	
	public String getMensagemErro() {
		return mensagemErro.getTexto();
	}
	
	public void setMensagemInformacao( String texto ) {
		mensagemInformacao.setTexto( texto );
	}
	
	public String getMensagemInformacao() {
		return mensagemInformacao.getTexto();
	}
	
	public boolean isAutoRetirarMensagens() {
		return autoRetirarMensagens;
	}
	
	public void setAutoRetirarMensagens( boolean autoRetirarMensagens ) {
		this.autoRetirarMensagens = autoRetirarMensagens;
	}
	
	public boolean isAutoValidarTudo() {
		return autoValidarTudo;
	}
	
	public void setAutoValidarTudo( boolean autoValidarTudo ) {
		this.autoValidarTudo = autoValidarTudo;
	}
	
	public boolean isAutoCriarAlerta() {
		return autoCriarAlerta;
	}
	
	/**
	 * Determina que se deve {@link Viagem#mostrar(Alerta) mostrar} o {@link #criarAlerta()} em {@link #antesDeMostrar(TomaraQueCaia, Viagem)}. 
	 */
	public void setAutoCriarAlerta( boolean autoCriarAlerta ) {
		this.autoCriarAlerta = autoCriarAlerta;
	}
	
	/**
	 * Converte a {@link #setMensagemErro(String) mensagem de erro} ou a {@link #setMensagemInformacao(String) informa��o} para {@link Alerta}.
	 * @return <code>null</code> caso n�o haja qualquer mensagem.
	 */
	public Alerta criarAlerta() {
		
		if( mensagemErro.getTexto() != null ){
			
			return Alerta.novoErro( getTitulo(), mensagemErro.getTexto() );
			
		}else if( mensagemInformacao.getTexto() != null ){
			
			return Alerta.novaInformacao( getTitulo(), mensagemInformacao.getTexto() );
			
		}
		
		return null;
		
	}
	
}
