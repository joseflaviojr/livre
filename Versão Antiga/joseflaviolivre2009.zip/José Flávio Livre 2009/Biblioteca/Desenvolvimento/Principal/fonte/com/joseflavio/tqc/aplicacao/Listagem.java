
/*
 *  Copyright (C) 2009 Jos� Fl�vio de Souza Dias J�nior
 *  
 *  This file is part of Jos� Fl�vio Livre - <http://www.joseflavio.com/livre/>.
 *  
 *  Jos� Fl�vio Livre is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *  
 *  Jos� Fl�vio Livre is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Jos� Fl�vio Livre. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.tqc.aplicacao;

import java.util.ArrayList;
import java.util.List;

import com.joseflavio.tqc.Dado;
import com.joseflavio.tqc.TomaraQueCaiaException;
import com.joseflavio.tqc.Viagem;
import com.joseflavio.tqc.dado.Comando;
import com.joseflavio.tqc.molde.ListaMolde;
import com.joseflavio.tqc.molde.ListaMolde.ListaColuna;
import com.joseflavio.tqc.molde.ListaMolde.ListaFiltro;
import com.joseflavio.util.Lista;

/**
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2009
 */
public abstract class Listagem<TQC extends AplicacaoTQC, ELEMENTO> extends BaseInformacao<TQC> {
	
	private ListaMolde<ELEMENTO> listaMolde;
	
	private boolean primeiraAmostragem = true;
	
	private boolean autoAtualizar = true;
	
	/**
	 * @see #construir()
	 */
	public Listagem( TQC aplicacao, String titulo, String banner, String subtitulo, boolean subtituloCentral ) throws TomaraQueCaiaException {
		
		super( aplicacao, titulo, banner, subtitulo, subtituloCentral );
		
		listaMolde = new ListaMolde<ELEMENTO>();
		listaMolde.setColunas( new ArrayList<ListaColuna<ELEMENTO>>() );
		listaMolde.setLista( new ArrayList<ELEMENTO>() );
		
	}
	
	public Listagem( TQC aplicacao, String titulo, String subtitulo, boolean subtituloCentral ) throws TomaraQueCaiaException {
		this( aplicacao, titulo, null, subtitulo, subtituloCentral );
	}

	public Listagem( TQC aplicacao, String titulo, String banner, String subtitulo ) throws TomaraQueCaiaException {
		this( aplicacao, titulo, banner, subtitulo, false );
	}

	public Listagem( TQC aplicacao, String titulo, String subtitulo ) throws TomaraQueCaiaException {
		this( aplicacao, titulo, null, subtitulo, false );
	}
	
	protected void construir() throws TomaraQueCaiaException {
		
		super.construir();
		
		/*----------------------*/
		
		listaMolde.getColunas().clear();
		colunas();
		
		listaMolde.getLista().clear();
		objetos( listaMolde.getLista() );
		
		listaMolde.construir( this );
		
		maisQuebraDeLinha();
		
		/*----------------------*/
		
		comandos();

		maisQuebraDeLinha();
		
		/*----------------------*/
		
		rodape();
		
		/*----------------------*/
		
	}
	
	/**
	 * Deve executar {@link #maisColuna(ListaMolde.ListaColuna)} para cada {@link ListaMolde.ListaColuna} desejada.
	 */
	protected abstract void colunas() throws TomaraQueCaiaException;
	
	/**
	 * Deve preencher a {@link Lista} com os objetos a serem mostrados.
	 */
	protected abstract void objetos( List<ELEMENTO> lista ) throws TomaraQueCaiaException;
	
	/**
	 * Deve executar {@link #mais(Comando)} para cada {@link Comando} desejado.
	 */
	protected abstract void comandos() throws TomaraQueCaiaException;
	
	/**
	 * Invocado depois de {@link #comandos()}. Esta implementa��o nada faz.
	 */
	protected void rodape() throws TomaraQueCaiaException {
	}
	
	protected final Listagem<TQC, ELEMENTO> maisColuna( ListaColuna<ELEMENTO> coluna ){
		listaMolde.maisColuna( coluna );
		return this;
	}
	
	protected final Listagem<TQC, ELEMENTO> maisColunaTexto( Class<? extends Object> classe, String atributo ){
		listaMolde.maisColunaTexto( classe, atributo );
		return this;
	}
	
	protected final Listagem<TQC, ELEMENTO> maisColunaData( Class<? extends Object> classe, String atributo ){
		listaMolde.maisColunaData( classe, atributo );
		return this;		
	}
	
	protected final Listagem<TQC, ELEMENTO> maisColunaInteiro( Class<? extends Object> classe, String atributo ){
		listaMolde.maisColunaInteiro( classe, atributo );
		return this;		
	}
	
	protected final Listagem<TQC, ELEMENTO> maisColunaReal( Class<? extends Object> classe, String atributo ){
		listaMolde.maisColunaReal( classe, atributo );
		return this;		
	}
	
	protected final Listagem<TQC, ELEMENTO> maisColunaBinario( Class<? extends Object> classe, String atributo, String valorVerdadeiro, String valorFalso ){
		listaMolde.maisColunaBinario( classe, atributo, valorVerdadeiro, valorFalso );
		return this;		
	}
	
	protected final Listagem<TQC, ELEMENTO> maisColunaConversao( Class<? extends Object> classe, String atributo, Object[] lista, String original, String convertido ){
		listaMolde.maisColunaConversao( classe, atributo, lista, original, convertido );
		return this;		
	}
	
	protected final Listagem<TQC, ELEMENTO> mais( Comando comando ){
		
		comando.setEspacoTextualPosterior( true );
		mais( (Dado) comando );
		
		return this;
		
	}
	
	/**
	 * Remove as colunas e os objetos e reinvoca {@link #colunas()} e {@link #objetos(List)}. 
	 */
	public void atualizar() throws TomaraQueCaiaException {
		
		listaMolde.getColunas().clear();
		colunas();
		
		listaMolde.getLista().clear();
		objetos( listaMolde.getLista() );
		
		listaMolde.atualizar( this );
		
	}
	
	public ELEMENTO getElemento( int indice ) {
		
		return listaMolde.getLista().get( indice );
		
	}
	
	public Listagem<TQC, ELEMENTO> setFiltro( ListaFiltro<ELEMENTO> filtro ) {
		listaMolde.setFiltro( filtro );
		return this;
	}
	
	public int getTotalDeLinhas() {
		return listaMolde.getLista().size();
	}
	
	/**
	 * @see #isAutoAtualizar()
	 */
	protected final void antesDeMostrar( Viagem viagem ) throws TomaraQueCaiaException {
		
		if( primeiraAmostragem ){
			primeiraAmostragem = false;
		}else{
			if( autoAtualizar ) atualizar();
		}
		
		antesDeMostrarListagem( viagem );
		
	}

	protected void antesDeMostrarListagem( Viagem viagem ) throws TomaraQueCaiaException {
	}
	
	public void setAutoAtualizar( boolean autoAtualizar ) {
		this.autoAtualizar = autoAtualizar;
	}
	
	public boolean isAutoAtualizar() {
		return autoAtualizar;
	}
	
}
