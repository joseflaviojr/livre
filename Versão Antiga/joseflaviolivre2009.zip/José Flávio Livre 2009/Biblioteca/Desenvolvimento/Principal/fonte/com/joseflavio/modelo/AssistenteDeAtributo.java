
/*
 *  Copyright (C) 2009 Jos� Fl�vio de Souza Dias J�nior
 *  
 *  This file is part of Jos� Fl�vio Livre - <http://www.joseflavio.com/livre/>.
 *  
 *  Jos� Fl�vio Livre is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *  
 *  Jos� Fl�vio Livre is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Jos� Fl�vio Livre. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.modelo;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2009
 */
public class AssistenteDeAtributo {
	
	private Class<? extends Object> classe;
	
	private String atributo;
	
	private Field campo;
	
	private Method metodoGet;
	
	public AssistenteDeAtributo( Class<? extends Object> classe, String atributo ) {
		
		this.classe = classe;
		this.atributo = atributo;
		
	}
	
	public Class<? extends Object> getClasse() {
		return classe;
	}
	
	public String getAtributo() {
		return atributo;
	}

	public static Field getCampo( Class<? extends Object> classe, String atributo ) {
		
		try{
			
			return classe.getDeclaredField( atributo );
			
		}catch( Exception e ){
			throw new IllegalArgumentException( "Atributo " + classe.getName() + "." + atributo + " desconhecido." ); 
		}
		
	}
	
	public Field getCampo() {
		
		if( campo == null ){
			try{
				campo = classe.getDeclaredField( atributo );
			}catch( Exception e ){
				throw new IllegalArgumentException( "Atributo " + classe.getName() + "." + atributo + " desconhecido." ); 
			}
		}
		
		return campo;
		
	}
	
	public Method getMetodoGet() {
		
		if( metodoGet == null ){
			
			String prefixo = getCampo().getType() == boolean.class ? "is" : "get";
			
			try{
				
				metodoGet = classe.getDeclaredMethod( prefixo + Character.toUpperCase( atributo.charAt( 0 ) ) + atributo.substring( 1 ) );
				
			}catch( NoSuchMethodException e ){
				throw new IllegalArgumentException( "M�todo GET para " + classe.getName() + "." + atributo + " desconhecido." ); 
			}
			
		}
		
		return metodoGet;
		
	}
	
	public Object invocarGet( Object objeto ) {
		
		try{
			
			return getMetodoGet().invoke( objeto );
			
		}catch( IllegalAccessException e ){
			throw new IllegalArgumentException( "M�todo GET para " + classe.getName() + "." + atributo + " desconhecido." ); 
		}catch( InvocationTargetException e ){
			throw new IllegalArgumentException( "M�todo GET para " + classe.getName() + "." + atributo + " desconhecido." );
		}
		
	}
	
	public static Method getMetodoGet( Class<? extends Object> classe, String atributo ) {

		String prefixo = getCampo( classe, atributo ).getType() == boolean.class ? "is" : "get";
		
		try{
			
			return classe.getDeclaredMethod( prefixo + Character.toUpperCase( atributo.charAt( 0 ) ) + atributo.substring( 1 ) );
			
		}catch( NoSuchMethodException e ){
			throw new IllegalArgumentException( "M�todo GET para " + classe.getName() + "." + atributo + " desconhecido." ); 
		}
		
	}
	
	public static Object invocarGet( Object objeto, String atributo ) {
		
		Class<? extends Object> classe = objeto.getClass();
		
		try{
			
			return getMetodoGet( classe, atributo ).invoke( objeto );
			
		}catch( IllegalAccessException e ){
			throw new IllegalArgumentException( "M�todo GET para " + classe.getName() + "." + atributo + " desconhecido." ); 
		}catch( InvocationTargetException e ){
			throw new IllegalArgumentException( "M�todo GET para " + classe.getName() + "." + atributo + " desconhecido." );
		}
		
	}
	
	public static <T extends Annotation> T getAnotacao( Class<? extends Object> classe, String atributo, Class<T> tipo, boolean obrigatorio ) {
		T jf = getCampo( classe, atributo ).getAnnotation( tipo );
		if( obrigatorio && jf == null ) throw new IllegalArgumentException( tipo.getName() + " n�o encontrado." );
		return jf;
	}
	
	public static JFApresentacao getJFApresentacao( Class<? extends Object> classe, String atributo, boolean obrigatorio ) {
		Class<JFApresentacao> tipo = JFApresentacao.class;
		JFApresentacao jf = getCampo( classe, atributo ).getAnnotation( tipo );
		if( obrigatorio && jf == null ) throw new IllegalArgumentException( tipo.getName() + " n�o encontrado." );
		return jf;
	}

	public <T extends Annotation> T getAnotacao( Class<T> tipo, boolean obrigatorio ) {
		T jf = getCampo().getAnnotation( tipo );
		if( obrigatorio && jf == null ) throw new IllegalArgumentException( tipo.getName() + " n�o encontrado." );
		return jf;
	}
	
	public JFAcesso getJFAcesso( boolean obrigatorio ) {
		return getAnotacao( JFAcesso.class, obrigatorio );
	}
	
	public JFApresentacao getJFApresentacao( boolean obrigatorio ) {
		return getAnotacao( JFApresentacao.class, obrigatorio );
	}
	
	public JFData getJFData( boolean obrigatorio ) {
		return getAnotacao( JFData.class, obrigatorio );
	}
	
	public JFInteiro getJFInteiro( boolean obrigatorio ) {
		return getAnotacao( JFInteiro.class, obrigatorio );
	}
	
	public JFReal getJFReal( boolean obrigatorio ) {
		return getAnotacao( JFReal.class, obrigatorio );
	}
	
	public JFTexto getJFTexto( boolean obrigatorio ) {
		return getAnotacao( JFTexto.class, obrigatorio );
	}
	
	public JFValidacaoNaoNulo getJFValidacaoNaoNulo( boolean obrigatorio ) {
		return getAnotacao( JFValidacaoNaoNulo.class, obrigatorio );
	}
	
	public JFValidacaoNaoVazio getJFValidacaoNaoVazio( boolean obrigatorio ) {
		return getAnotacao( JFValidacaoNaoVazio.class, obrigatorio );
	}
	
	public JFValidacaoPrimitiva getJFValidacaoPrimitiva( boolean obrigatorio ) {
		return getAnotacao( JFValidacaoPrimitiva.class, obrigatorio );
	}
	
	public JFValidacaoTamanhoLimite getJFValidacaoTamanhoLimite( boolean obrigatorio ) {
		return getAnotacao( JFValidacaoTamanhoLimite.class, obrigatorio );
	}
	
	public JFValidacaoValorLimite getJFValidacaoValorLimite( boolean obrigatorio ) {
		return getAnotacao( JFValidacaoValorLimite.class, obrigatorio );
	}

}
