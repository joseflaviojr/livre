
/*
 *  Copyright (C) 2009 Jos� Fl�vio de Souza Dias J�nior
 *  
 *  This file is part of Jos� Fl�vio Livre - <http://www.joseflavio.com/livre/>.
 *  
 *  Jos� Fl�vio Livre is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *  
 *  Jos� Fl�vio Livre is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Jos� Fl�vio Livre. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.tqc.aplicacao;

import com.joseflavio.cultura.Cultura;
import com.joseflavio.tqc.EstiloFonte;
import com.joseflavio.tqc.TomaraQueCaia;

/**
 * Modelo de {@link TomaraQueCaia}.
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2009
 */
public abstract class AplicacaoTQC extends TomaraQueCaia {

	public AplicacaoTQC( String titulo, Cultura cultura, EstiloFonte estiloFonte ) {
		
		super( titulo, cultura );
		
		if( estiloFonte != null ) mais( estiloFonte );
		
	}
	
	public AplicacaoTQC( String titulo ) {
		
		this( titulo, null, null );
		
	}
	
	public abstract String getBanner();
	
	public abstract String getBannerPequeno();
	
	public abstract void persistirPendencias() throws BancoDeDadosException;
	
}
