
/*
 *  Copyright (C) 2009 Jos� Fl�vio de Souza Dias J�nior
 *  
 *  This file is part of Jos� Fl�vio Livre - <http://www.joseflavio.com/livre/>.
 *  
 *  Jos� Fl�vio Livre is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *  
 *  Jos� Fl�vio Livre is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Jos� Fl�vio Livre. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.tqc;

import com.joseflavio.IncapacidadeException;
import com.joseflavio.validacao.MultiplaValidacao;
import com.joseflavio.validacao.Validacao;
import com.joseflavio.validacao.ValidacaoException;

/**
 * Elemento de uma {@link Informacao}.
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2009
 */
public abstract class Dado {

	private boolean visivel = true;
	
	public Dado() {
	}
	
	public abstract Object getConteudo();

	/**
	 * Retorna o conte�do {@link #validar() validado}.
	 */
	public final Object getConteudoValidado() throws ValidacaoException {
		validar();
		return getConteudo();
	}
	
	/**
	 * Valida o conte�do do {@link Dado} de acordo com a sua {@link Validacao}.<br>
	 * A n�o implementa��o de {@link ValidacaoDeConteudo} n�o impede a invoca��o deste m�todo.
	 * @throws ValidacaoException proveniente da {@link Validacao}.
	 * @see ValidacaoPrimitiva
	 * @see ValidacaoDeConteudo
	 * @see #getConteudo()
	 */
	public final void validar() throws ValidacaoException {
		
		if( this instanceof ValidacaoPrimitiva ){
			
			ValidacaoPrimitiva vp = (ValidacaoPrimitiva) this;
			
			if( vp.getConteudoInvalido() != null ){
				
				String nome = this instanceof Identificacao ? ((Identificacao)this).getNome() : null;
				
				throw ValidacaoException.novoErro( nome, vp.getConteudoInvalido(), vp.getMensagemValidacaoPrimitiva() );
				
			}
			
		}
		
		if( this instanceof ValidacaoDeConteudo ){
			
			Validacao validacao = ((ValidacaoDeConteudo)this).getValidacao();
			
			if( validacao != null ) validacao.validar( getConteudo() );
			
		}
		
	}
	
	/**
	 * Constr�i a {@link ValidacaoDeConteudo#getValidacao()} atrav�s de {@link MultiplaValidacao}.
	 * @throws IncapacidadeException caso este {@link Dado} n�o implemente {@link ValidacaoDeConteudo}.
	 */
	public Dado mais( Validacao v ){
		
		if( ! ( this instanceof ValidacaoDeConteudo ) ) throw new IncapacidadeException();
			
		ValidacaoDeConteudo vc = (ValidacaoDeConteudo) this;
		Validacao validacao = vc.getValidacao();
		
		if( validacao == null ) validacao = v;
		else if( validacao instanceof MultiplaValidacao ) ((MultiplaValidacao)validacao).mais( v );
		else validacao = new MultiplaValidacao( validacao ).mais( v );
		
		vc.setValidacao( validacao );
		
		return this;
		
	}
	
	public boolean isVisivel() {
		return visivel;
	}
	
	public Dado setVisivel( boolean visivel ) {
		this.visivel = visivel;
		return this;
	}
	
}
