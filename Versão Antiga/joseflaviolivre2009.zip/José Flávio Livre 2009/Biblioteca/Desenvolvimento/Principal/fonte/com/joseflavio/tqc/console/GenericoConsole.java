
/*
 *  Copyright (C) 2009 Jos� Fl�vio de Souza Dias J�nior
 *  
 *  This file is part of Jos� Fl�vio Livre - <http://www.joseflavio.com/livre/>.
 *  
 *  Jos� Fl�vio Livre is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *  
 *  Jos� Fl�vio Livre is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Jos� Fl�vio Livre. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.tqc.console;

import java.io.IOException;
import java.util.Formatter;
import java.util.Scanner;

import com.joseflavio.cultura.Cultura;

/**
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2009
 */
public class GenericoConsole extends Console {

	private java.io.Console console;
	
	private Scanner scanner;
	
	private Formatter formatter;
	
	private int corTexto = COR_BRANCA;
	private int corTextoFundo = COR_PRETA;
	
	public GenericoConsole( Cultura cultura ) {
		
		super( cultura );

		console = System.console();
		scanner = new Scanner( System.in );
		formatter = new Formatter( System.out );
		
	}

	public int getTotalColunas(){
		return 80;
	}
	
	public int getTotalLinhas(){
		return 50;
	}
	
	public void setCorTexto( int cor ){
		this.corTexto = cor;
	}
	
	public int getCorTexto() {
		return corTexto;
	}
	
	public void setCorTextoFundo( int cor ){
		this.corTextoFundo = cor;
	}
	
	public int getCorTextoFundo() {
		return corTextoFundo;
	}
	
	public void limpar(){
	}
	
	public char esperar( boolean mostrar ) throws IOException {
		
		if( console != null ){
			
			if( mostrar ){
				String s;
				do s = console.readLine(); while( s != null && s.length() == 0 );
				if( s != null ) return s.charAt( 0 );
			}else{
				char[] s;
				do s = console.readPassword(); while( s != null && s.length == 0 );
				if( s != null ) return s[ 0 ];
			}
			
		}
			
		String s;
		do s = scanner.nextLine(); while( s != null && s.length() == 0 );
		if( s != null ) return s.charAt( 0 );
		
		throw new IOException( "Recurso indispon�vel" );
		
	}
	
	public void setTelaCheia( boolean cheia ){
	}
	
	public String receber() throws IOException {
		
		if( console != null ){
			String s = console.readLine();
			if( s != null ) return s;
		}
			
		String s = scanner.nextLine();
		if( s != null ) return s;
		
		throw new IOException( "Recurso indispon�vel" );
		
	}
	
	public void enviar( String texto ) {
		System.out.print( texto );
	}
	
	public void enviarln( String texto ) {
		System.out.println( texto );
	}
	
	public void enviarln() {
		System.out.println();
	}
	
	public void enviar( String formato, Object... args ) {
		formatter.format( formato, args );
	}

}
